------------------------------------------------------------
REAME.txt
Bjorn Stenger 2006
------------------------------------------------------------

Hand image data

format: single frames in ppm format,
size: 320x240,
frame rate: recorded at 30fps, but the framerate dropped 
during capturing.

seq 01 - point (86 frames)
pointing hand

seq 02 - turnflat (161 frames)
hand turning along arm axis, first 180 degrees and back,
then 90 degrees and back

seq 03 - openclose (89 frames)
hand opening and closeing twice, once in fixed pose, once
with some rotation along arm axis


------------------------------------------------------------


This data was used in the paper:

@Article{StengerPAMI06,
  author = 	 {Stenger, B. and Thayananthan, A. and  Torr, P. H. S. and Cipolla, R.},
  title = 	 {Model-Based Hand Tracking Using a Hierarchical Bayesian Filter},
  journal = 	 {Trans. PAMI},
  year = 	 {2006},
  volume = 	 {28},
  number = 	 {9},
  pages = 	 {1372--1384,},
  month = 	 {September}
}

Please cite this if you use the data. The data is public, use is free.

It was also used in some previous papers, check
http://mi.eng.cam.ac.uk/~bdrs2/pubs.html

Thanks!
Bjorn


